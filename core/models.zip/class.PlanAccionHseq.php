<?php
class PlanAccionHseq {
  private $id;
  private $db;
  private $nombre_archivo;
  private $destination;
  private $ruta;
  private $filename;
  public function __construct() {
    $this->db = new Conexion();
  }
  private function Errors($url,$add_mode = false) {
    global $_planaccionhseq;
    try {
      if(!array_key_exists($_POST['id'],$_planaccionhseq)) {
        throw new Exception(1);
      } else {
        $this->id = $_POST['id'];
        $this->nombre_archivo = $_FILES['gerencia']['name'];
        $this->ruta = 'views/app/images/archivos/plan_accion_hseq/';
        $this->destination = $this->ruta.basename($_FILES['gerencia']['name']);
        $this->filename = $_FILES['gerencia']['tmp_name'];
        move_uploaded_file($this->filename, $this->destination);
      }


    } catch(Exception $error) {
      header('location: ' . $url . $error->getMessage());
      exit;
    }
  }
  public function AddOperativo() {
    $this->id = intval($_GET['id']);
    $this->Errors('?view=plan_accion_hseq&mode=add_operativo&error=',true);
    $this->db->query("UPDATE plan_accion_hseq SET operativos='$this->nombre_archivo' WHERE id='$this->id';");
    header('location: ?view=plan_accion_hseq&mode=add_operativo&success=true');
  }
  public function AddGerencial() {
    $this->id = intval($_GET['id']);
    $this->Errors('?view=plan_accion_hseq&mode=add_gerencial&error=',true);
    $this->db->query("UPDATE plan_accion_hseq SET mandos_m='$this->nombre_archivo' WHERE id='$this->id';");
    header('location: ?view=plan_accion_hseq&mode=add_gerencial&success=true');
  }

  public function AddGeneral() {
    $this->id = intval($_GET['id']);
    $this->Errors('?view=plan_accion_hseq&mode=add_general&error=',true);
    $this->db->query("UPDATE plan_accion_hseq SET general='$this->nombre_archivo' WHERE id='$this->id';");
    header('location: ?view=plan_accion_hseq&mode=add_general&success=true');
  }

  public function __destruct() {
    $this->db->close();
  }
}
?>
