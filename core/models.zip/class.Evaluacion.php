<?php
class Evaluacion {
  private $id;
  private $db;
  private $usuario;
  private $evaluador;
  private $user;
  private $eval;
  private $historial;

  public function __construct() {
    $this->db = new Conexion();
  }
  private function Errors($url,$add_mode = false) {
    global $_users, $_evaluacion;
    try {
      if(empty($_POST['evalua'])) {
        throw new Exception(1);
      } else {
        $evaluador = intval($_POST['evalua']);

      }

    } catch(Exception $error) {
      header('location: ' . $url . $error->getMessage());
      exit;
    }
  }
  public function Add() {

    $cont = count($_POST['usuario']);
    for ($i=1; $i <= $cont; $i++) {
      $this->evaluador = intval($_POST['evalua']);
      $this->usuario = intval($_POST['usuario'.$i]);
      $this->Errors('?view=evaluacion&mode=add&error='.$cont.'&contador='.$cont);
      $this->query = $this->db->query("INSERT INTO resultadosevaluacion (id_usuario,evaluador)
      VALUES ('$this->usuario','$this->evaluador');");
    }

    header('location: ?view=evaluacion&mode=add&success=true&contador='.$cont);
  }
  public function AddHist() {
    $this->historial = $_GET['id'];
    $this->Errors('?view=evaluacion&mode=addHist&error=');
    $this->db->query("INSERT INTO historial_evaluacion (aprobado) VALUES ('$this->historial');");
    header('location: ?view=user&mode=addHist&success=true');
  }
  public function Delete() {
    $this->user = $_GET['id_user'];
    $this->eval = $_GET['evaluador'];
    $contador = count($_GET["nombre"]);


    $query = "DELETE FROM resultadosevaluacion WHERE id_usuario='$this->user' AND evaluador='$this->eval';";
    $this->db->multi_query($query);
    header('location: ?view=evaluacion&mode=add&success=true');
  }

  public function __destruct() {
    $this->db->close();
  }
}
?>
